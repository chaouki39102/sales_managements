// ════════════════════════════════════════════════
// resources/js/pages/lookups/WarehousesPage.tsx
// ════════════════════════════════════════════════
import LookupPage from './LookupPage';

export default function WarehousesPage() {
  return (
    <LookupPage
      title="المستودعات"
      resource="مستودع"
      endpoint="/warehouses"
      icon="ti-building-warehouse"
      color="var(--teal)"
      fields={[
        { key: 'name',     label: 'اسم المستودع', required: true,  placeholder: 'مثال: المستودع الرئيسي' },
        { key: 'location', label: 'الموقع',         placeholder: 'مثال: ورقلة — المنطقة الصناعية'        },
        { key: 'capacity', label: 'السعة',          type: 'number', placeholder: 'مثال: 1000'             },
        { key: 'description', label: 'الوصف',       type: 'textarea', showInTable: false                  },
      ]}
    />
  );
}
