// ════════════════════════════════════════════════
// resources/js/routes/index.tsx
// ════════════════════════════════════════════════
import React, { lazy, Suspense } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import DashboardLayout from '@/components/layouts/DashboardLayout';

// Lazy load pages
const LoginPage      = lazy(() => import('@/pages/auth/LoginPage'));
const DashboardPage  = lazy(() => import('@/pages/dashboard/DashboardPage'));

// Lookup pages (بسيطة لا تعتمد على واجهات أخرى)
const UnitsPage      = lazy(() => import('@/pages/lookups/UnitsPage'));
const CurrenciesPage = lazy(() => import('@/pages/lookups/CurrenciesPage'));
const BrandsPage     = lazy(() => import('@/pages/lookups/BrandsPage'));
const FamiliesPage   = lazy(() => import('@/pages/lookups/FamiliesPage'));
const WarehousesPage = lazy(() => import('@/pages/lookups/WarehousesPage'));
const PriceLevelsPage = lazy(() => import('@/pages/lookups/PriceLevelsPage'));
const TvasPage       = lazy(() => import('@/pages/lookups/TvasPage'));

// TODO: uncomment as you build them
// const ProductsPage   = lazy(() => import('@/pages/products/ProductsPage'));
// const InvoicesPage   = lazy(() => import('@/pages/invoices/InvoicesPage'));
// const POSPage        = lazy(() => import('@/pages/pos/POSPage'));

// ── Loading spinner ───────────────────────────────
function Loader() {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      height: '100vh', background: 'var(--bg0)',
    }}>
      <i className="ti ti-loader-2" style={{
        fontSize: 32, color: 'var(--em)',
        animation: 'spin 0.8s linear infinite',
      }} />
    </div>
  );
}

// ── Protected route ────────────────────────────────
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();
  if (isLoading) return <Loader />;
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

// ── Placeholder for unbuilt pages ─────────────────
function ComingSoon() {
  return (
    <div className="page on">
      <div className="empty" style={{ paddingTop: 80 }}>
        <div className="empty-ic"><i className="ti ti-hammer" /></div>
        <div className="empty-tx">هذه الصفحة قيد الإنشاء</div>
        <div className="empty-sub">سيتم إضافتها قريباً</div>
      </div>
    </div>
  );
}

// ── Main router ────────────────────────────────────
export function AppRoutes() {
  return (
    <Suspense fallback={<Loader />}>
      <Routes>
        {/* Public */}
        <Route path="/login" element={<LoginPage />} />

        {/* Protected — all under DashboardLayout */}
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard"   element={<DashboardPage />} />

          {/* ── Lookup pages (مكتملة) ── */}
          <Route path="units"       element={<UnitsPage />} />
          <Route path="currencies"  element={<CurrenciesPage />} />
          <Route path="brands"      element={<BrandsPage />} />
          <Route path="categories"  element={<FamiliesPage />} />
          <Route path="warehouses"  element={<WarehousesPage />} />
          <Route path="pricelevels" element={<PriceLevelsPage />} />
          <Route path="tva-rates"   element={<TvasPage />} />

          {/* ── Coming soon ── */}
          <Route path="pos"         element={<ComingSoon />} />
          <Route path="invoices"    element={<ComingSoon />} />
          <Route path="orders"      element={<ComingSoon />} />
          <Route path="returns"     element={<ComingSoon />} />
          <Route path="quotations"  element={<ComingSoon />} />
          <Route path="bl"          element={<ComingSoon />} />
          <Route path="products"    element={<ComingSoon />} />
          <Route path="inventory"   element={<ComingSoon />} />
          <Route path="suppliers"   element={<ComingSoon />} />
          <Route path="clients"     element={<ComingSoon />} />
          <Route path="finance"     element={<ComingSoon />} />
          <Route path="expenses"    element={<ComingSoon />} />
          <Route path="debts"       element={<ComingSoon />} />
          <Route path="tva"         element={<ComingSoon />} />
          <Route path="fiscal"      element={<ComingSoon />} />
          <Route path="fiscalyears" element={<ComingSoon />} />
          <Route path="reports"     element={<ComingSoon />} />
          <Route path="balance"     element={<ComingSoon />} />
          <Route path="users"       element={<ComingSoon />} />
          <Route path="settings"    element={<ComingSoon />} />
          <Route path="employees"   element={<ComingSoon />} />
        </Route>

        {/* Catch all */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Suspense>
  );
}
