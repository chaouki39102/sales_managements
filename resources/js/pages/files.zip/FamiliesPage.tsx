// ════════════════════════════════════════════════
// resources/js/pages/lookups/FamiliesPage.tsx
// ════════════════════════════════════════════════
import LookupPage from './LookupPage';

export default function FamiliesPage() {
  return (
    <LookupPage
      title="فئات المنتجات"
      resource="فئة"
      endpoint="/families"
      icon="ti-folder-open"
      color="var(--purple)"
      fields={[
        { key: 'name',        label: 'اسم الفئة',   required: true,  placeholder: 'مثال: أغذية' },
        { key: 'description', label: 'الوصف',        type: 'textarea', showInTable: false        },
      ]}
    />
  );
}
