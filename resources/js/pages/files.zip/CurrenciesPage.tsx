// ════════════════════════════════════════════════
// resources/js/pages/lookups/CurrenciesPage.tsx
// ════════════════════════════════════════════════
import LookupPage from './LookupPage';

export default function CurrenciesPage() {
  return (
    <LookupPage
      title="العملات"
      resource="عملة"
      endpoint="/currencies"
      icon="ti-currency-dollar"
      color="var(--gold)"
      fields={[
        { key: 'name',   label: 'اسم العملة',  required: true,  placeholder: 'مثال: دينار جزائري' },
        { key: 'code',   label: 'الرمز',        required: true,  placeholder: 'مثال: DZD'           },
        { key: 'symbol', label: 'الإشارة',      placeholder: 'مثال: دج'                            },
        { key: 'is_default', label: 'افتراضي', type: 'select', showInTable: true, badge: true,
          options: [{ value: 1, label: 'نعم' }, { value: 0, label: 'لا' }] },
      ]}
    />
  );
}
