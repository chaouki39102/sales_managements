// ════════════════════════════════════════════════
// resources/js/pages/lookups/LookupPage.tsx
// مكوّن عام لصفحات CRUD البسيطة
// ════════════════════════════════════════════════
import React, { useState, useRef } from 'react';
import { useLookup } from '@/hooks/useLookup';

// ── Types ──────────────────────────────────────
export interface FieldDef {
  key:          string;
  label:        string;
  type?:        'text' | 'number' | 'select' | 'textarea';
  placeholder?: string;
  options?:     { value: string | number; label: string }[];
  required?:    boolean;
  /** عرض في الجدول */
  showInTable?: boolean;
  /** يُعرض في الجدول كـ badge */
  badge?:       boolean;
  badgeColor?:  string;
}

export interface LookupPageProps {
  /** عنوان الصفحة العربي */
  title:    string;
  /** اسم المورد بالعربي (للرسائل) */
  resource: string;
  /** مسار الـ API */
  endpoint: string;
  /** تعريفات الحقول */
  fields:   FieldDef[];
  /** لون الأيقونة */
  color?:   string;
  /** أيقونة الصفحة */
  icon?:    string;
  /** هل يدعم الكلمة المفردة؟ */
  emptyText?: string;
}

// ── Modal ──────────────────────────────────────
function Modal({
  title, children, onClose, saving,
}: {
  title: string;
  children: React.ReactNode;
  onClose: () => void;
  saving: boolean;
}) {
  return (
    <div
      className="modal-back"
      style={{
        position: 'fixed', inset: 0, zIndex: 500,
        background: 'rgba(0,0,0,.45)', backdropFilter: 'blur(3px)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 16,
      }}
      onClick={onClose}
    >
      <div
        className="card"
        style={{ width: '100%', maxWidth: 480, maxHeight: '90vh', overflow: 'auto' }}
        onClick={e => e.stopPropagation()}
      >
        <div className="card-hd">
          <div className="card-title">{title}</div>
          <button className="btn btn-xs" onClick={onClose} disabled={saving}>
            <i className="ti ti-x" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ── Confirm delete ─────────────────────────────
function ConfirmModal({
  name, onConfirm, onClose, saving,
}: {
  name: string; onConfirm: () => void; onClose: () => void; saving: boolean;
}) {
  return (
    <div
      style={{
        position: 'fixed', inset: 0, zIndex: 600,
        background: 'rgba(0,0,0,.5)', display: 'flex',
        alignItems: 'center', justifyContent: 'center', padding: 16,
      }}
      onClick={onClose}
    >
      <div
        className="card"
        style={{ maxWidth: 380, width: '100%' }}
        onClick={e => e.stopPropagation()}
      >
        <div style={{ textAlign: 'center', padding: '8px 0 16px' }}>
          <i className="ti ti-alert-triangle" style={{ fontSize: 40, color: 'var(--red)' }} />
          <div style={{ fontSize: 15, fontWeight: 800, color: 'var(--t1)', marginTop: 12 }}>
            تأكيد الحذف
          </div>
          <div style={{ fontSize: 13, color: 'var(--t3)', marginTop: 8 }}>
            هل تريد حذف <strong>{name}</strong>؟<br />
            <span style={{ fontSize: 11.5, color: 'var(--red)' }}>لا يمكن التراجع عن هذا الإجراء.</span>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 8 }}>
          <button className="btn" onClick={onClose} disabled={saving}>إلغاء</button>
          <button className="btn btn-r" onClick={onConfirm} disabled={saving}>
            {saving ? <i className="ti ti-loader-2" style={{ animation: 'spin .8s linear infinite' }} /> : <i className="ti ti-trash" />}
            حذف
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main LookupPage ─────────────────────────────
export default function LookupPage({
  title, resource, endpoint, fields, color = 'var(--em)', icon = 'ti-list', emptyText,
}: LookupPageProps) {
  const { items, loading, error, saving, refetch, create, update, remove } = useLookup<any>(endpoint);

  const [search,   setSearch]   = useState('');
  const [modal,    setModal]    = useState<'add' | 'edit' | null>(null);
  const [editItem, setEditItem] = useState<any | null>(null);
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [formErr,  setFormErr]  = useState<string | null>(null);
  const [delItem,  setDelItem]  = useState<any | null>(null);
  const [toast,    setToast]    = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

  // ── Filtered list ─────────────────────────────
  const tableFields = fields.filter(f => f.showInTable !== false);
  const nameField   = fields[0]?.key ?? 'name';

  const filtered = items.filter(item =>
    !search || String(item[nameField] ?? '').toLowerCase().includes(search.toLowerCase())
  );

  // ── Toast helper ──────────────────────────────
  function showToast(msg: string, type: 'success' | 'error' = 'success') {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  }

  // ── Open add modal ────────────────────────────
  function openAdd() {
    const defaults: Record<string, any> = {};
    fields.forEach(f => { defaults[f.key] = ''; });
    setFormData(defaults);
    setFormErr(null);
    setEditItem(null);
    setModal('add');
  }

  // ── Open edit modal ───────────────────────────
  function openEdit(item: any) {
    const data: Record<string, any> = {};
    fields.forEach(f => { data[f.key] = item[f.key] ?? ''; });
    setFormData(data);
    setFormErr(null);
    setEditItem(item);
    setModal('edit');
  }

  // ── Submit ─────────────────────────────────────
  async function handleSubmit() {
    // Validate required
    for (const f of fields) {
      if (f.required && !formData[f.key]) {
        setFormErr(`حقل "${f.label}" إلزامي`);
        return;
      }
    }
    setFormErr(null);
    try {
      if (modal === 'add') {
        await create(formData);
        showToast(`تمت إضافة ${resource} بنجاح`);
      } else if (editItem) {
        await update(editItem.id, formData);
        showToast(`تم تعديل ${resource} بنجاح`);
      }
      setModal(null);
    } catch (e: any) {
      setFormErr(e.message);
    }
  }

  // ── Delete ─────────────────────────────────────
  async function handleDelete() {
    if (!delItem) return;
    try {
      await remove(delItem.id);
      showToast(`تم حذف ${resource} بنجاح`);
    } catch (e: any) {
      showToast(e.message, 'error');
    }
    setDelItem(null);
  }

  // ── Render ─────────────────────────────────────
  return (
    <div className="page on" style={{ padding: '18px 20px' }}>

      {/* Toast */}
      {toast && (
        <div style={{
          position: 'fixed', top: 20, left: '50%', transform: 'translateX(-50%)',
          zIndex: 9999, padding: '10px 20px', borderRadius: 'var(--r2)',
          background: toast.type === 'success' ? 'var(--em)' : 'var(--red)',
          color: '#fff', fontSize: 13, fontWeight: 700,
          boxShadow: '0 4px 20px rgba(0,0,0,.25)',
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <i className={`ti ${toast.type === 'success' ? 'ti-check' : 'ti-x'}`} />
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 38, height: 38, borderRadius: 10,
            background: `color-mix(in srgb, ${color} 12%, transparent)`,
            border: `1px solid color-mix(in srgb, ${color} 25%, transparent)`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color, fontSize: 18,
          }}>
            <i className={`ti ${icon}`} />
          </div>
          <div>
            <div style={{ fontSize: 16, fontWeight: 800, color: 'var(--t1)' }}>{title}</div>
            <div style={{ fontSize: 11.5, color: 'var(--t4)' }}>
              {loading ? 'جارٍ التحميل...' : `${items.length} عنصر`}
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {/* Search */}
          <div className="srch" style={{ width: 200 }}>
            <span className="srch-ic ic ic-xs"><i className="ti ti-search" /></span>
            <input
              type="text"
              placeholder="بحث..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <button className="btn" onClick={refetch} title="تحديث">
            <i className="ti ti-refresh" />
          </button>
          <button className="btn btn-p" onClick={openAdd}>
            <i className="ti ti-plus" />
            إضافة {resource}
          </button>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div style={{
          padding: '12px 16px', marginBottom: 16, borderRadius: 'var(--r2)',
          background: 'var(--redb)', border: '1px solid var(--redbo)',
          color: 'var(--red)', fontSize: 13, display: 'flex', gap: 8, alignItems: 'center',
        }}>
          <i className="ti ti-alert-circle" />
          {error}
          <button
            className="btn btn-xs btn-r"
            style={{ marginRight: 'auto' }}
            onClick={refetch}
          >
            إعادة المحاولة
          </button>
        </div>
      )}

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 200, gap: 10, color: 'var(--t3)' }}>
            <i className="ti ti-loader-2" style={{ fontSize: 22, animation: 'spin .8s linear infinite' }} />
            جارٍ تحميل البيانات...
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 200, gap: 8, color: 'var(--t4)' }}>
            <i className="ti ti-inbox" style={{ fontSize: 36 }} />
            <div style={{ fontSize: 13, fontWeight: 600 }}>
              {search ? 'لا توجد نتائج للبحث' : (emptyText ?? `لا توجد ${title} بعد`)}
            </div>
            {!search && (
              <button className="btn btn-p btn-sm" onClick={openAdd} style={{ marginTop: 4 }}>
                إضافة أول {resource}
              </button>
            )}
          </div>
        ) : (
          <div className="tw">
            <table>
              <thead>
                <tr>
                  <th style={{ width: 48 }}>#</th>
                  {tableFields.map(f => (
                    <th key={f.key}>{f.label}</th>
                  ))}
                  <th style={{ width: 100, textAlign: 'center' }}>إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((item, idx) => (
                  <tr key={item.id}>
                    <td className="m" style={{ color: 'var(--t4)', fontSize: 11 }}>{idx + 1}</td>
                    {tableFields.map(f => (
                      <td key={f.key}>
                        {f.badge ? (
                          <span className={`bx be`} style={f.badgeColor ? { color: f.badgeColor } : {}}>
                            {item[f.key] ?? '—'}
                          </span>
                        ) : (
                          <span style={idx === 0 && f.key === nameField ? { fontWeight: 700, color: 'var(--t1)' } : {}}>
                            {item[f.key] ?? <span style={{ color: 'var(--t4)' }}>—</span>}
                          </span>
                        )}
                      </td>
                    ))}
                    <td>
                      <div style={{ display: 'flex', gap: 4, justifyContent: 'center' }}>
                        <button
                          className="btn btn-xs"
                          onClick={() => openEdit(item)}
                          title="تعديل"
                        >
                          <i className="ti ti-pencil" />
                        </button>
                        <button
                          className="btn btn-xs btn-r"
                          onClick={() => setDelItem(item)}
                          title="حذف"
                        >
                          <i className="ti ti-trash" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Footer */}
        {filtered.length > 0 && (
          <div style={{
            padding: '9px 16px', borderTop: '1px solid var(--b1)',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <span style={{ fontSize: 12, color: 'var(--t4)' }}>
              {search ? `${filtered.length} نتيجة من ${items.length}` : `${items.length} عنصر`}
            </span>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      {modal && (
        <Modal
          title={modal === 'add' ? `إضافة ${resource} جديد` : `تعديل ${resource}`}
          onClose={() => setModal(null)}
          saving={saving}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {fields.map(f => (
              <div key={f.key}>
                <label style={{ fontSize: 12, fontWeight: 700, color: 'var(--t2)', display: 'block', marginBottom: 5 }}>
                  {f.label}
                  {f.required && <span style={{ color: 'var(--red)', marginRight: 3 }}>*</span>}
                </label>
                {f.type === 'textarea' ? (
                  <textarea
                    value={formData[f.key] ?? ''}
                    onChange={e => setFormData(d => ({ ...d, [f.key]: e.target.value }))}
                    placeholder={f.placeholder}
                    rows={3}
                    style={{
                      width: '100%', boxSizing: 'border-box',
                      padding: '8px 12px', borderRadius: 'var(--r2)',
                      border: '1px solid var(--b3)', background: 'var(--bg1)',
                      color: 'var(--t1)', fontSize: 13, fontFamily: 'Tajawal, sans-serif',
                      outline: 'none', resize: 'vertical',
                    }}
                  />
                ) : f.type === 'select' ? (
                  <select
                    value={formData[f.key] ?? ''}
                    onChange={e => setFormData(d => ({ ...d, [f.key]: e.target.value }))}
                    style={{
                      width: '100%', padding: '8px 12px', borderRadius: 'var(--r2)',
                      border: '1px solid var(--b3)', background: 'var(--bg1)',
                      color: 'var(--t1)', fontSize: 13, fontFamily: 'Tajawal, sans-serif',
                      outline: 'none',
                    }}
                  >
                    <option value="">— اختر —</option>
                    {f.options?.map(o => (
                      <option key={o.value} value={o.value}>{o.label}</option>
                    ))}
                  </select>
                ) : (
                  <input
                    type={f.type ?? 'text'}
                    value={formData[f.key] ?? ''}
                    onChange={e => setFormData(d => ({ ...d, [f.key]: e.target.value }))}
                    placeholder={f.placeholder}
                    style={{
                      width: '100%', boxSizing: 'border-box',
                      padding: '8px 12px', borderRadius: 'var(--r2)',
                      border: '1px solid var(--b3)', background: 'var(--bg1)',
                      color: 'var(--t1)', fontSize: 13, fontFamily: 'Tajawal, sans-serif',
                      outline: 'none',
                    }}
                  />
                )}
              </div>
            ))}

            {formErr && (
              <div style={{
                padding: '8px 12px', borderRadius: 'var(--r2)',
                background: 'var(--redb)', color: 'var(--red)',
                fontSize: 12.5, display: 'flex', alignItems: 'center', gap: 6,
              }}>
                <i className="ti ti-alert-circle" />
                {formErr}
              </div>
            )}

            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', paddingTop: 4 }}>
              <button className="btn" onClick={() => setModal(null)} disabled={saving}>إلغاء</button>
              <button className="btn btn-p" onClick={handleSubmit} disabled={saving}>
                {saving
                  ? <i className="ti ti-loader-2" style={{ animation: 'spin .8s linear infinite' }} />
                  : <i className={`ti ${modal === 'add' ? 'ti-plus' : 'ti-check'}`} />
                }
                {modal === 'add' ? 'إضافة' : 'حفظ التعديلات'}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Delete confirm */}
      {delItem && (
        <ConfirmModal
          name={delItem[nameField] ?? `#${delItem.id}`}
          onConfirm={handleDelete}
          onClose={() => setDelItem(null)}
          saving={saving}
        />
      )}
    </div>
  );
}
