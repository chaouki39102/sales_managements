# هيكل الـ API Layer الجديد

## مخطط الملفات

```
resources/js/
├── lib/
│   ├── api/
│   │   ├── core/
│   │   │   ├── client.ts          ← Axios instance + interceptors (موجود في new-arch)
│   │   │   ├── queryClient.ts     ← React Query config (موجود في new-arch)
│   │   │   ├── queryKeys.ts       ← مفاتيح هرمية (موجود في new-arch)
│   │   │   └── types.ts           ← [✅ جديد] أنواع مكتملة
│   │   ├── endpoints/
│   │   │   ├── auth.ts            ← (موجود في new-arch)
│   │   │   ├── companies.ts       ← (موجود في new-arch)
│   │   │   ├── fiscalYears.ts     ← (موجود في new-arch)
│   │   │   ├── lookups.ts         ← (موجود في new-arch)
│   │   │   ├── seeds.ts           ← (موجود في new-arch)
│   │   │   ├── useResource.ts     ← (موجود في new-arch)
│   │   │   ├── documents.ts       ← [✅ جديد]
│   │   │   ├── parties.ts         ← [✅ جديد]
│   │   │   ├── products.ts        ← [✅ جديد]
│   │   │   ├── payments.ts        ← [✅ جديد]
│   │   │   ├── expenses.ts        ← [✅ جديد]
│   │   │   ├── inventory.ts       ← [✅ جديد]
│   │   │   ├── users.ts           ← [✅ جديد]
│   │   │   ├── settings.ts        ← [✅ جديد]
│   │   │   ├── dashboard.ts       ← [✅ جديد]
│   │   │   └── reports.ts         ← [✅ جديد]
│   │   └── index.ts               ← [✅ جديد] تصدير مركزي
│   └── store/
│       └── appStore.ts            ← (موجود في new-arch)
├── context/
│   ├── AuthContext.tsx            ← (موجود في new-arch)
│   └── FiscalYearContext.tsx      ← (موجود في new-arch)
├── routes/
│   └── index.tsx                  ← [✅ جديد] كامل
└── App.tsx                        ← [✅ جديد]
```

## خريطة الملفات (مصدر → وجهة)

| الملف المُسلَّم      | المسار الصحيح                                    |
|---------------------|--------------------------------------------------|
| App.tsx             | resources/js/App.tsx                             |
| routes_index.tsx    | resources/js/routes/index.tsx                    |
| types_complete.ts   | resources/js/lib/api/core/types.ts               |
| lib_api_full_index  | resources/js/lib/api/index.ts                    |
| index_exports.ts    | resources/js/lib/api/index.ts (بديل أبسط)        |
| useDocuments.ts     | resources/js/lib/api/endpoints/documents.ts      |
| useDashboard.ts     | resources/js/lib/api/endpoints/dashboard.ts      |
| useParties_full.ts  | resources/js/lib/api/endpoints/parties.ts        |
| useProducts_full.ts | resources/js/lib/api/endpoints/products.ts       |
| useUsers.ts         | resources/js/lib/api/endpoints/users.ts          |
| useExpenses.ts      | resources/js/lib/api/endpoints/expenses.ts       |
| usePayments.ts      | resources/js/lib/api/endpoints/payments.ts       |
| useInventory.ts     | resources/js/lib/api/endpoints/inventory.ts      |
| useSettings.ts      | resources/js/lib/api/endpoints/settings.ts       |
| useReports.ts       | resources/js/lib/api/endpoints/reports.ts        |

## تثبيت الـ packages المطلوبة

```bash
npm install zustand immer @tanstack/react-query-devtools
```

## خطوات الترحيل

1. ضع ملفات `new-merged-architecture.md` (appStore, auth, AuthContext, client,
   companies, FiscalYearContext, fiscalYears, lookups, queryClient, queryKeys,
   seeds, useResource) في مساراتها الصحيحة.

2. أضف الملفات الجديدة من هذا المجلد.

3. في `App.tsx` — الدالة `connectSlugToInterceptor` تُنفَّذ مرة واحدة عند بدء
   التطبيق لربط Zustand بالـ HTTP interceptor.

4. احذف الملفات القديمة:
   - resources/js/lib/api.ts (القديم)
   - resources/js/lib/api/client.ts (القديم)
   - resources/js/hooks/useData.ts (القديم)
   - resources/js/hooks/useDashboard.ts (القديم)
   - resources/js/hooks/useLookups.ts (القديم)
   - resources/js/context/AuthContext.tsx (القديم — استبدل بالجديد)

## مبادئ الهيكل الجديد

- **React Query** = كل server state (جلب، تعديل، كاش)
- **Zustand** = client state فقط (slug الشركة، السنة المالية، السايدبار، الثيم)
- **Interceptor** يقرأ الـ slug من Zustand مباشرة (بدون localStorage)
- **هرمية مفاتيح الكاش**: `[slug, resource, ...]` → إبطال تلقائي عند تغيير الشركة
- **createResourceHooks** = factory لإنشاء hooks كاملة لأي resource جديد بـ 3 أسطر
